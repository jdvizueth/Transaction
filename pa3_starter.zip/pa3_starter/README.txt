Name: Jose Vizueth
NetID: jdv72

Challenges Attempted (Tier I/II/III): none
